﻿using IntellveDashboard.UI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;

namespace IntellveDashboard.UI.Pages.Dashboard
{
    public class MainModel : PageModel
    {
        [BindProperty]
        public List<DeviceType> deviceTypelist { get; set; }

        [BindProperty]
        public List<Operator> operatorlist { get; set; }

        [BindProperty]
        public List<Branch> branchIdlist { get; set; }

        private readonly IOptions<ConfigSettingsModel> _settings;
        
        public MainModel(IOptions<ConfigSettingsModel> settings)
        {
            _settings = settings;
        } 

        public void OnGet()
        {
            deviceTypelist = new List<DeviceType>()
            {
                new DeviceType() {Text="Shutter Sensor", Value="Shutter Sensor"},
                new DeviceType() { Text="PIR Sensor", Value="PIR Sensor"}
            };

            operatorlist = new List<Operator>()
            {
                new Operator() {Text="mafil1", Value="mafil1"},
                new Operator() { Text="mafil1support", Value="mafil1support"},
                new Operator() { Text="mafil2", Value="mafil2"},
                new Operator() { Text="mafil3", Value="mafil3"},
                new Operator() { Text="mafil4", Value="mafil4"},
                new Operator() { Text="mafil5", Value="mafil5"} 
            };
            branchIdlist = new List<Branch>()
            {
                new Branch() {Text="", Value=""},
                new Branch() { Text="", Value=""}
            };


            using (var client = new HttpClient())
            {
                var endPoint = _settings.Value.web_API_SERVICE_HOSTS.dashboard_WEB_API_HOST + "/api/Dashboard/GetDeviceTypes";
                var json = client.GetStringAsync(endPoint).Result;
                var deviceType = JsonConvert.DeserializeObject(json);
                deviceTypelist = new List<DeviceType>()
                {
                    new DeviceType() {Text=deviceType., Value="Shutter Sensor"},
                };

            }

            using (var client = new HttpClient())
            {
                var endPoint = _settings.Value.web_API_SERVICE_HOSTS.dashboard_WEB_API_HOST + "/api/Dashboard/GetBranches";
                var json = client.GetStringAsync(endPoint).Result; 
                operatorlist = json.;
            }

            using (var client = new HttpClient())
            {
                var endPoint = _settings.Value.web_API_SERVICE_HOSTS.dashboard_WEB_API_HOST + "/api/Dashboard/GetOperators";
                var json = client.GetStringAsync(endPoint).Result;
                operatorlist = json.;
            } 
        }
    }
}